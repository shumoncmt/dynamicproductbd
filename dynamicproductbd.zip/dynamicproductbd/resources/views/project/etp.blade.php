<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Effluent Treatment Plant in Bangladesh - Best industrial electric motor in Bangladesh | Dynamic Motor</title>
    <meta name="description" content="Discover advanced effluent treatment solutions in Bangladesh. Our plant ensures sustainable waste management and environmental protection for a cleaner future" />
    <meta name="keywords" content="our state-of-the-art effluent treatment plant in Bangladesh, designed to efficiently manage wastewater and promote eco-friendly practices.">
    
    @include('master.header')

</head>
<body>
    


</body>









@include('master.footer')
