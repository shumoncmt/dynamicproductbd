<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ultra Pure Water Treatment Plant in Bangladesh - Best industrial electric motor in Bangladesh | Dynamic Motor </title>
    <meta name="description" content="Ultra Pure Water Treatment Plant in Bangladesh, dedicated to providing clean, safe water solutions for communities and industries." />
    <meta name="keywords" content="Ultra Pure Water Treatment Plant in Bangladesh, committed to delivering high-quality water treatment services for a healthier future.">
    
    @include('master.header')

</head>
<body>


</body>









@include('master.footer')