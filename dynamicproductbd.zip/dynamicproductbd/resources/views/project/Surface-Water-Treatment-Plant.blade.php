<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Surface Water Treatment Plant in Bangladesh - Best industrial electric motor in Bangladesh | Dynamic Motor</title>
    <meta name="description" content="The innovative surface water treatment plant in Bangladesh, ensuring clean and safe water for communities. Learn about our advanced technologies and solutions." />
    <meta name="keywords" content="The surface water treatment plant in Bangladesh, a key initiative for sustainable water management. Join us in promoting clean water access for all.">
    
    @include('master.header')

</head>
<body>

</body>









@include('master.footer')