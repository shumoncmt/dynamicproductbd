<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mobile Water Treatment Plant in Bangladesh - Best industrial electric motor in Bangladesh | Dynamic Motor</title>
    <meta name="description" content="Explore Bangladesh's innovative membrane-based desalination plant, delivering efficient and sustainable freshwater solutions for communities in need." />
    <meta name="keywords" content="The membrane-based desalination plant in Bangladesh, transforming seawater into clean drinking water and promoting sustainable development.">
    
    @include('master.header')

</head>
<body>

</body>









@include('master.footer')