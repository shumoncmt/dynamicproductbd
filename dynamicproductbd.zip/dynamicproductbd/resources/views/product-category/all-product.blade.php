<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Product - Best industrial electric motor in Bangladesh | Dynamic Motor</title>
    <meta name="description" content="wide variety of products designed for every lifestyle. Browse our selection to find quality items that cater to your unique preferences" />
    <meta name="keywords" content="wide variety of products designed for every lifestyle. Browse our selection to find quality items that cater to your unique preferences">
    
    @include('master.header')

</head>
<body>
    

</body>











@include('master.footer')